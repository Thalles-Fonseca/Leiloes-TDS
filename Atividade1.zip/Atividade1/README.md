# Leiloes-TDS
Projeto criado para acompanhar a rotina da casa de leiloes.
Tecnologias usadas: Java, MySQL, Netbeans.
